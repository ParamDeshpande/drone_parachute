# stm32bluepill-blink
Blink sample for STM32 Blue Pill. Based on PlatformIO and libopencm3

Check out the article:

https://medium.com/@ly.lee/stm32-blue-pill-analyse-and-optimise-your-ram-and-rom-9fc805e16ed7?source=friends_link&sk=54719084d640bb1d92ac1097d623bba2
